<?php
$errors = array();

if(isset ($_POST['register'])){
    $username = preg_replace ('/[^A-Za-z]/', '', $_POST['username']);
    $email = $_POST['email'];
    $password = $_POST['password'];
    $con_password = $_POST['con_password']; 
    if(file_exists('users/' . $username . '.xml')){
        $errors[] = 'Korisnicko ime vec postoji';
        }
    if($username == ''){
        $errors [] = 'Potrebno je upisati korisnicko ime';
    }
    if($email == ''){
        $errors [] = 'Potrebno je upisati email';
    }
    if($password == '' || $con_password == ''){
        $errors [] = 'Potrebno je upisati lozinku i potvrdu lozinke';
    }
    if($password != $con_password){
        $errors[] = 'Lozinke se moraju podudarati';
    }
    if(count($errors) == 0){
        $xml = new SimpleXMLElement('<user></user>');
        $xml->addChild ('password', md5($password)); 
        $xml->addChild ('email', $email); 
        $xml->asXML ('users/'. $username . '.xml');
        header ('Location: login.php');
        die;
    }
  
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registracija</title>
</head>
<body>

<h1>Registracija</h1>
    <form method="post" action="">

        <p>Korisnicko ime <input type="text" name="username" size="20" /></p>
        <p>Email <input type="text" name="email" size="20" /></p>
        <p>Lozinka <input type="password" name="password" size="20" /></p>
        <p>Potvrda lozinke <input type="password" name="con_password" size="20" /></p>
        
        <?php
        
        if(count($errors) > 0){
            echo '<ul>';
            foreach($errors as $e){
                echo '<li style="color:red;">' . $e . '</li>';
            }
            echo '</ul>';

        }

    ?>
        
        <p><input type="submit" value="Registriraj se" name="register" /></p>
    
    </form>
    <a href="login.php">Login</a>
</body>
</html>