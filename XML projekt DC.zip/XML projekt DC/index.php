<?php
session_start();
if(!file_exists('users/' . $_SESSION ['username'] . '.xml')){
    header('Location: login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Korisnicka stranica</title>
</head>
<body>

    <h1>Korisnicka stranica</h1>
    <h2>Dobrodosli, <?php echo $_SESSION ['username']; ?>!</h2>
    
    <h3>Lista registriranih korisnika:</h3>

    <table>
        <tr>
            <th>Korisnicko ime</th>
            <th>Email</th>
        </tr>
        <?php
        $files = glob('users/*.xml');
        foreach($files as $file){
            $xml = new SimpleXMLElement ($file, 0, true);
            echo '
            <tr>
                <td>'. basename($file, '.xml') .'</td>
                <td>'. $xml->email .'</td>
            </tr> ';
        }
        ?>
    </table>

    <hr />
    <a href="logout.php">Logout</a>

</body>
</html>