<?php
$error = false;
if(isset($_POST['login'])){
    $username = preg_replace ('/[^A-Za-z]/', '', $_POST['username']);
    $password = md5($_POST['password']);
    if(file_exists('users/' . $username . '.xml')){
        $xml = new SimpleXMLElement ('users/' . $username . '.xml', 0, true);
        if($password == $xml->password){
            session_start();
            $_SESSION['username'] = $username;
            header ('Location: index.php');
            die;
        }
    }
    $error = true;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <form method="post" action="">
        <p>Korisnicko ime <input type="text" name="username" size="20" /></p>
        <p>Lozinka <input type="password" name="password" size="20" /></p>
        <?php
            if($error){
                echo '<p style="color:red;">Ne postoji korisnik s ovim podatcima</p>';
            }
        ?>
        <p><input type="submit" value="Login" name="login" /></p>
    </form>
    <a href="register.php">Registriraj se</a>
</body>
</html>